const config = {
    DB: {
        
        user: 'testing',
        password: 'Uuxwp7Mcxo7Khy',
        server: 'cobazsqlcis410.database.windows.net', // You can use 'localhost\\instance' to connect to named instance
        database: 'josephka',
 
    },

    JWT: "mysupersecret",
};
module.exports = config;

